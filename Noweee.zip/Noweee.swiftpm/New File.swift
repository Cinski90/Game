import SwiftUI

struct MapView: View {
    @ObservedObject var gameManager: GameManager
    @Binding var zoomLevel: CGFloat
    
    var body: some View {
        ForEach(0..<gameManager.map.grid.count, id: \.self) { row in
            ForEach(0..<gameManager.map.grid[row].count, id: \.self) { col in
                let tile = gameManager.map.grid[row][col]
                Rectangle()
                    .fill(tileColor(for: tile.type))
                    .frame(width: gameManager.map.tileSize, height: gameManager.map.tileSize)
                    .position(
                        x: CGFloat(col) * gameManager.map.tileSize + gameManager.map.tileSize / 2,
                        y: CGFloat(row) * gameManager.map.tileSize + gameManager.map.tileSize / 2
                    )
                    .onTapGesture(count: 2) {
                        let position = CGPoint(
                            x: CGFloat(col) * gameManager.map.tileSize + gameManager.map.tileSize / 2,
                            y: CGFloat(row) * gameManager.map.tileSize + gameManager.map.tileSize / 2
                        )
                        gameManager.towerManager.moveTower(to: position)
                    }
            }
        }
    }
    
    func tileColor(for type: TileType) -> Color {
        switch type {
        case .path: return .gray
        case .towerSpot: return .green
        case .empty: return .brown
        }
    }
}

