import SwiftUI

class TowerManager {
    weak var gameManager: GameManager? // Reference to GameManager
    
    var selectedTower: Tower? = nil // Track the selected tower
    
    func placeTower(at position: CGPoint) {
        guard let gameManager = gameManager else { return }
        
        let col = Int(position.x / gameManager.map.tileSize)
        let row = Int(position.y / gameManager.map.tileSize)
        
        if row >= 0 && row < gameManager.map.grid.count && col >= 0 && col < gameManager.map.grid[0].count {
            if gameManager.map.grid[row][col].type == .towerSpot && gameManager.resourceManager.deploymentPoints >= 50 {
                let tower = Tower(
                    position: CGPoint(x: CGFloat(col) * gameManager.map.tileSize + gameManager.map.tileSize / 2, y: CGFloat(row) * gameManager.map.tileSize + gameManager.map.tileSize / 2),
                    range: 100,
                    damage: 10
                )
                gameManager.towers.append(tower)
                gameManager.resourceManager.deploymentPoints -= 50
                gameManager.map.grid[row][col].type = .empty
                print("Tower placed. Total towers: \(gameManager.towers.count), remaining deployment points: \(gameManager.resourceManager.deploymentPoints)")
            } else {
                print("Cannot place tower here. Tile type: \(gameManager.map.grid[row][col].type), deployment points: \(gameManager.resourceManager.deploymentPoints)")
            }
        }
    }
    
    func updateTowers(_ towers: [Tower], timePassed: TimeInterval) {
        for tower in towers {
            if tower.movementPoints < 2 {
                var remainingTime = timePassed
                while remainingTime > 0 && tower.movementPoints < 2 {
                    if tower.movementCooldown <= remainingTime {
                        remainingTime -= tower.movementCooldown
                        tower.movementPoints += 1
                        tower.movementCooldown = 10.0
                    } else {
                        tower.movementCooldown -= remainingTime
                        remainingTime = 0
                    }
                }
            }
        }
    }
    
    func handleTowerAttacks(towers: [Tower], enemies: inout [Enemy]) {
        for tower in towers {
            for enemy in enemies {
                if tower.distance(from: tower.position, to: enemy.position) <= tower.range {
                    tower.attack(enemy: enemy)
                }
            }
        }
    }
    
    func selectTower(_ tower: Tower) {
        selectedTower = tower
    }
    
    func moveTower(to position: CGPoint) {
        guard let gameManager = gameManager, let selectedTower = selectedTower else { return }
        
        if gameManager.movementSystem.moveTower(selectedTower, to: position, in: gameManager.map) {
            self.selectedTower = nil
        }
    }
}
